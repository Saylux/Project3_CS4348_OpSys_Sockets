Compile and Run:

To compile and run the code, type 'make s' to run the server and then type 'make c' to run the client. It must be done in this order. You must make sure that you are in the directory that contains the makefile and the .java files.